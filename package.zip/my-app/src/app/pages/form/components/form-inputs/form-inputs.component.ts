import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-inputs',
  templateUrl: './form-inputs.component.html',
  styleUrls: ['./form-inputs.component.scss']
})
export class FormInputsComponent implements OnInit {

  constructor() { }

  ngOnInit() { }
}
