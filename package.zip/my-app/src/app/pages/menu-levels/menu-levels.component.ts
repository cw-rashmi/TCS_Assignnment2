import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-levels',
  template: `<router-outlet></router-outlet>`
})
export class MenuLevelsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
