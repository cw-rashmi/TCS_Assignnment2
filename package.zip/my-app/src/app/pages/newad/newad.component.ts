import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newad',
  templateUrl: './newad.component.html',
  styleUrls: ['./newad.component.scss']
})
export class NewadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
