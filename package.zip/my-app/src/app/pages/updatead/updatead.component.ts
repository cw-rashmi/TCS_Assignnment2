import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatead',
  template: `<router-outlet></router-outlet>`,
})
export class UpdateadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
